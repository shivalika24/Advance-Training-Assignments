# Online Book Store

## Introduction
 This is a online book store web application.This is written in jsp mvc.
 
 ## Current Functionalities
 
 * Login
 * Registration
 * Logout
 * Update Profile
 * Browse Books
 * Query Books
 * Add to cart
 * Update cart
 * Clear Cart
 * Remove item from cart
 * Order History
 * Admin panel
 * Report Generation
 
 **Other Contributor**

[Rinkal Singh](https://github.com/Rk-niit)

 
 
